import React from "react";
import './Person.css'
import { TextField } from "@material-ui/core";
const Person = ({ fullName, deleted, changed }) => {
    return (
        <div className="person">
            <p>{` ${fullName} `}</p>
            <TextField
            label="نام کامل"
            placeholder={fullName} onChange={changed}
          />
            <button onClick={deleted}>حذف</button>
        </div>
    );
};

export default Person;
