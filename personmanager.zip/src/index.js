import React from "react";
import { render } from "react-dom";
import App from "./App";
import "./index.css";
import { create } from "jss";
import rtl from "jss-rtl";
import {
  StylesProvider,
  jssPreset,
  ThemeProvider,
} from "@material-ui/core/styles";
import { createMuiTheme } from "@material-ui/core";

// Configure JSS
const jss = create({ plugins: [...jssPreset().plugins, rtl()] });

function RTL(props) {
  return <StylesProvider jss={jss}>{props.children}</StylesProvider>;
}
const theme = createMuiTheme({
  direction: "rtl",
});
render(
  <ThemeProvider theme={theme}>
    <RTL>
      <App />
    </RTL>
  </ThemeProvider>,
  document.getElementById("root")
);