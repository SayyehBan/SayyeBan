import React, { Component } from "react";
import Persons from "./components/Person/Persons";
import { TextField } from "@material-ui/core";
class App extends Component {
  state = {
    persons: [],
    person: "",
    showPersons: false,
  };
  handlerShowPerson = () => {
    this.setState({ showPersons: !this.state.showPersons });
    // console.log(this.state.showPersons);
  };
  handlerDeletePerson = (id) => {
    const persons = [...this.state.persons];
    const filteredPersons = persons.filter((p) => p.id !== id);
    this.setState({ persons: filteredPersons });
  };

  handlerChangePerson = (event, id) => {
    const { persons: allPersons } = this.state;
    const personsIndex = allPersons.findIndex((p) => p.id === id);
    const person = allPersons[personsIndex];
    person.fullName = event.target.value;
    console.log(event);
    const persons = [...allPersons];
    persons[personsIndex] = person;
    this.setState({ persons });
  };
  handlerNewPerson = () => {
    const persons = [...this.state.persons];
    const person = {
      id: Math.floor(Math.random() * 1000),
      fullName: this.state.person,
    };
    persons.push(person);
    this.setState({ persons, person: "" });
  };
  setPerson = (event) => {
    this.setState({ person: event.target.value });
  };
  render() {
    const { persons, showPersons } = this.state;
    // InlineStyle text-align
    // <div style={{ textAlign: "center" }}>
    const styles = {
      textAlign: "center",
    };
    const buttonStyle = {
      padding: "1em",
      fontFamily: "BYekan",
      backgroundColor: "Blue",
    };
    let person = null;
    if (showPersons) {
      person = (
        <Persons
          persons={persons}
          personDelete={this.handlerDeletePerson}
          personChange={this.handlerChangePerson}
        />
      );
    }
    return (
      <div style={styles}>
        <h2>مدیریت کننده اشخاص</h2>
        <h3>
          تعداد اشخاص <u>{persons.length}</u> نفر میباشد.
        </h3>
        <div>
          <TextField
            label="ثبت شخص جدید"
            onChange={this.setPerson}
            value={this.state.person}
          />
          <button onClick={this.handlerNewPerson}>افزودن</button>
        </div>
        <button onClick={this.handlerShowPerson} style={buttonStyle}>
          {showPersons ? "عدم نمایش اشخاص" : "نمایش اشخاص"}
        </button>
        {person}
      </div>
    );
  }
}

export default App;
